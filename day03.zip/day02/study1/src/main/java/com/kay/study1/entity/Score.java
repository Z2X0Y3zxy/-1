package com.kay.study1.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


public class Score {

    private int scId;
    private int score;
    private String subject;

    @Override
    public String toString() {
        return "Score{" +
                "scId=" + scId +
                ", score=" + score +
                ", subject='" + subject + '\'' +
                '}';
    }

    public int getScId() {
        return scId;
    }

    public void setScId(int scId) {
        this.scId = scId;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Score() {
    }

    public Score(int scId, int score, String subject) {
        this.scId = scId;
        this.score = score;
        this.subject = subject;
    }
}
