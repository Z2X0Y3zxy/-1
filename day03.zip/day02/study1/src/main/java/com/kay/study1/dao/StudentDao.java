package com.kay.study1.dao;

import com.kay.study1.entity.Student;

import java.util.List;


public interface StudentDao {


    List<Student> selectAll();

    int add(Student student);

    int delete(int i);

    int update(Student student);
}
