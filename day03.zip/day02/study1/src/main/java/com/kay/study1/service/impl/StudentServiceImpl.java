package com.kay.study1.service.impl;

import com.kay.study1.dao.StudentDao;
import com.kay.study1.entity.Student;
import com.kay.study1.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentDao studentDao;

    @Override
    public List<Student> selectAll() {
        return studentDao.selectAll();
    }

    @Override
    public int add(Student student) {
        return studentDao.add(student);
    }

    @Override
    public int delete(int i) {
        return studentDao.delete(i);
    }

    @Override
    public int update(Student student) {
        return studentDao.update(student);
    }
}
