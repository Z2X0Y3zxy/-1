package com.kay.study1.Controller;

import com.kay.study1.entity.Student;
import com.kay.study1.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequestMapping("student")
@RestController
public class StudentController {

    @Autowired
    private StudentService studentService;

    @RequestMapping("selectAll")
    public Object selectAll(){
        List<Student> list=studentService.selectAll();
        return list;
    }

}
