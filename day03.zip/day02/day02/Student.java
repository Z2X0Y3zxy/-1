package com.sample;


public class Student {

  private long stuid;
  private String stuname;
  private long stuage;
  private long stuclsld;
  private String stuorigin;
  private String stuaddress;
  private String stuphone;


  public long getStuid() {
    return stuid;
  }

  public void setStuid(long stuid) {
    this.stuid = stuid;
  }


  public String getStuname() {
    return stuname;
  }

  public void setStuname(String stuname) {
    this.stuname = stuname;
  }


  public long getStuage() {
    return stuage;
  }

  public void setStuage(long stuage) {
    this.stuage = stuage;
  }


  public long getStuclsld() {
    return stuclsld;
  }

  public void setStuclsld(long stuclsld) {
    this.stuclsld = stuclsld;
  }


  public String getStuorigin() {
    return stuorigin;
  }

  public void setStuorigin(String stuorigin) {
    this.stuorigin = stuorigin;
  }


  public String getStuaddress() {
    return stuaddress;
  }

  public void setStuaddress(String stuaddress) {
    this.stuaddress = stuaddress;
  }


  public String getStuphone() {
    return stuphone;
  }

  public void setStuphone(String stuphone) {
    this.stuphone = stuphone;
  }

}
