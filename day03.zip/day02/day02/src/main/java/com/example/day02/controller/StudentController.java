package com.example.day02.controller;

import com.example.day02.Service.StudentService;
import com.example.day02.pojo.Stu;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("student")
@RestController
public class StudentController {

    @Autowired
    private StudentService studentService;

    @RequestMapping("/selectAll")
    public Object selectAll(){
        return studentService.selectAll();
    }

    @RequestMapping("/add")
    public Object add(Stu student){
        Stu student1 = new Stu();
        student1.setStuid(2);
        student1.setStuname("连连看");
        student1.setStuage(18);
        student1.setStuclsld(5);
        student1.setStuorigin("天津");
        student1.setStuaddress("湖南");
        student1.setStuphone("19837492041");
        int i=studentService.add(student1);
        if (i>0){
            return "成功";
        }else{
            return "失败";
        }
    }

    @RequestMapping("/update")
    public Object update(Stu student){
        student.setStuname("koko");
        student.setStuid(1);
        int i=studentService.update(student);
        if (i>0){
            return "成功";
        }else{
            return "失败";
        }
    }

    @RequestMapping("/delete")
    public Object delete(Integer stuid){

        int i=studentService.delete(2);
        if (i>0){
            return "成功";
        }else{
            return "失败";
        }
    }
}
