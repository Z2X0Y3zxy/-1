package com.example.day02.pojo;

public class Stu {
    private int stuid;
    private String stuname;
    private int stuage;
    private int stuclsld;
    private String stuorigin;
    private String stuaddress;
    private String stuphone;

    @Override
    public String toString() {
        return "Stu{" +
                "stuid=" + stuid +
                ", stuname='" + stuname + '\'' +
                ", stuage=" + stuage +
                ", stuclsld=" + stuclsld +
                ", stuorigin='" + stuorigin + '\'' +
                ", stuaddress='" + stuaddress + '\'' +
                ", stuphone='" + stuphone + '\'' +
                '}';
    }

    public int getStuid() {
        return stuid;
    }

    public void setStuid(int stuid) {
        this.stuid = stuid;
    }

    public String getStuname() {
        return stuname;
    }

    public void setStuname(String stuname) {
        this.stuname = stuname;
    }

    public int getStuage() {
        return stuage;
    }

    public void setStuage(int stuage) {
        this.stuage = stuage;
    }

    public int getStuclsld() {
        return stuclsld;
    }

    public void setStuclsld(int stuclsld) {
        this.stuclsld = stuclsld;
    }

    public String getStuorigin() {
        return stuorigin;
    }

    public void setStuorigin(String stuorigin) {
        this.stuorigin = stuorigin;
    }

    public String getStuaddress() {
        return stuaddress;
    }

    public void setStuaddress(String stuaddress) {
        this.stuaddress = stuaddress;
    }

    public String getStuphone() {
        return stuphone;
    }

    public void setStuphone(String stuphone) {
        this.stuphone = stuphone;
    }

    public Stu() {
    }

    public Stu(int stuid, String stuname, int stuage, int stuclsld, String stuorigin, String stuaddress, String stuphone) {
        this.stuid = stuid;
        this.stuname = stuname;
        this.stuage = stuage;
        this.stuclsld = stuclsld;
        this.stuorigin = stuorigin;
        this.stuaddress = stuaddress;
        this.stuphone = stuphone;
    }
}
