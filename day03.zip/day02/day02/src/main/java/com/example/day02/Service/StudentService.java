package com.example.day02.Service;

import com.example.day02.pojo.Stu;

import java.util.List;

public interface StudentService {
    List<Stu> selectAll();

    int add(Stu student);

    int update(Stu student);

    int delete(Integer stuid);
}
