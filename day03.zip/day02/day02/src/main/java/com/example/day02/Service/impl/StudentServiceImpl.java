package com.example.day02.Service.impl;

import com.example.day02.Service.StudentService;
import com.example.day02.dao.StudentDao;
import com.example.day02.pojo.Stu;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentDao studentDao;

    @Override
    public List<Stu> selectAll() {
        List<Stu> students = studentDao.selectAll();
        return students;
    }

    @Override
    public int add(Stu student) {
        return studentDao.add(student);
    }

    @Override
    public int update(Stu student) {
        int update = studentDao.update(student);
        return update;
    }

    @Override
    public int delete(Integer stuid) {
        return studentDao.delete(stuid);
    }
}
