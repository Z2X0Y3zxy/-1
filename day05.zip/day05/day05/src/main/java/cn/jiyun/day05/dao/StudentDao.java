package cn.jiyun.day05.dao;

import cn.jiyun.day05.pojo.Student;

import java.util.List;

public interface StudentDao {
    List<Student> selectAll();

    int delete(int id);

    int edit(Student student);

    int add(Student student);
}
