package cn.jiyun.day05.Service.impl;

import cn.jiyun.day05.Service.StudentService;
import cn.jiyun.day05.dao.StudentDao;
import cn.jiyun.day05.pojo.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentDao studentDao;

    @Override
    public List<Student> selectAll() {
        return studentDao.selectAll();
    }

    @Override
    public int add(Student student) {
        return studentDao.add(student);
    }

    @Override
    public int edit(Student student) {
        return studentDao.edit(student);
    }

    @Override
    public int delete(int id) {
        return studentDao.delete(id);
    }
}
