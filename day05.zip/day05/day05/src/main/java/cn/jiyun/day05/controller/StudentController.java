package cn.jiyun.day05.controller;

import cn.jiyun.day05.Service.StudentService;
import cn.jiyun.day05.pojo.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RequestMapping("student")
@RestController
public class StudentController {

    @Autowired
    private StudentService studentService;

    @RequestMapping("selectAll")
    @CrossOrigin
    public Object selectAll(){
        return studentService.selectAll();
    }

    @RequestMapping("add")
    @CrossOrigin
    public Object add(@RequestBody Student student){
        int i=0;
        i=studentService.add(student);
        return i;
    }

    @RequestMapping("edit")
    @CrossOrigin
    public Object edit(@RequestBody Student student){
        int i=0;
        i=studentService.edit(student);
        return i;
    }

    @RequestMapping("delete/{id}")
    @CrossOrigin
    public Object delete(@PathVariable("id") int id){
        int i=0;
        i=studentService.delete(id);
        return i;
    }

}
