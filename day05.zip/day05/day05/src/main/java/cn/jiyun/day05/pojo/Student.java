package cn.jiyun.day05.pojo;


public class Student {

  private long stuId;
  private String stuName;
  private long stuAge;
  private Classes cls;
  private String stuOrigin;
  private String stuAddress;
  private String stuPhone;


  public long getStuId() {
    return stuId;
  }

  public void setStuId(long stuId) {
    this.stuId = stuId;
  }


  public String getStuName() {
    return stuName;
  }

  public void setStuName(String stuName) {
    this.stuName = stuName;
  }


  public long getStuAge() {
    return stuAge;
  }

  public void setStuAge(long stuAge) {
    this.stuAge = stuAge;
  }


  public Classes getCls() {
    return cls;
  }

  public void setCls(Classes cls) {
    this.cls = cls;
  }

  public String getStuOrigin() {
    return stuOrigin;
  }

  public void setStuOrigin(String stuOrigin) {
    this.stuOrigin = stuOrigin;
  }


  public String getStuAddress() {
    return stuAddress;
  }

  public void setStuAddress(String stuAddress) {
    this.stuAddress = stuAddress;
  }


  public String getStuPhone() {
    return stuPhone;
  }

  public void setStuPhone(String stuPhone) {
    this.stuPhone = stuPhone;
  }

}
