package cn.jiyun.day05.Service;

import cn.jiyun.day05.pojo.Student;

import java.util.List;

public interface StudentService {
    List<Student> selectAll();

    int add(Student student);

    int edit(Student student);

    int delete(int id);
}
