package cn.jiyun.day05.pojo;


public class Score {

  private long scId;
  private long score;
  private long stuId;
  private String subject;


  public long getScId() {
    return scId;
  }

  public void setScId(long scId) {
    this.scId = scId;
  }


  public long getScore() {
    return score;
  }

  public void setScore(long score) {
    this.score = score;
  }


  public long getStuId() {
    return stuId;
  }

  public void setStuId(long stuId) {
    this.stuId = stuId;
  }


  public String getSubject() {
    return subject;
  }

  public void setSubject(String subject) {
    this.subject = subject;
  }

}
