package cn.jiyun.day05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day05ApplicationTests {

    @Test
    void contextLoads() {
    }

}
