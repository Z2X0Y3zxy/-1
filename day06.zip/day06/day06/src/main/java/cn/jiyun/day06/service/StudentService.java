package cn.jiyun.day06.service;

import cn.jiyun.day06.pojo.Student;

import java.util.List;

public interface StudentService {
    List<Student> selectAll();

    int add(Student student);

    int update(Student student);

    int delete(int id);
}
