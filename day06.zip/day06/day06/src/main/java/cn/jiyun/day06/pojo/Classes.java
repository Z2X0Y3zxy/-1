package cn.jiyun.day06.pojo;


public class Classes {

  private long clsId;
  private String clsName;


  public long getClsId() {
    return clsId;
  }

  public void setClsId(long clsId) {
    this.clsId = clsId;
  }


  public String getClsName() {
    return clsName;
  }

  public void setClsName(String clsName) {
    this.clsName = clsName;
  }

}
