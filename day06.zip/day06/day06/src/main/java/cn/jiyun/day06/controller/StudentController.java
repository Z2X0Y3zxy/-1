package cn.jiyun.day06.controller;

import cn.jiyun.day06.pojo.Student;
import cn.jiyun.day06.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RequestMapping("student")
@RestController
public class StudentController {

    @Autowired
    private StudentService studentService;

    @RequestMapping("selectAll")
    @CrossOrigin
    public Object selectAll(){
        return studentService.selectAll();
    }

    @RequestMapping("add")
    @CrossOrigin
    public Object add(@RequestBody Student student){
        int i=0;
        i=studentService.add(student);
        return i;
    }

    @RequestMapping("update")
    @CrossOrigin
    public Object update(@RequestBody Student student){
        int i=0;
        i=studentService.update(student);
        return i;
    }

    @RequestMapping("delete/{id}")
    @CrossOrigin
    public Object delete(@PathVariable("id")int id){
        int i=0;
        i=studentService.delete(id);
        return i;
    }

}
