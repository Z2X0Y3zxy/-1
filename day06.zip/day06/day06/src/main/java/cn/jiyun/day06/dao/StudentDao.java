package cn.jiyun.day06.dao;

import cn.jiyun.day06.pojo.Student;

import java.util.List;

public interface StudentDao {
    List<Student> selectAll();

    int add(Student student);

    int update(Student student);

    int delete(int id);
}
