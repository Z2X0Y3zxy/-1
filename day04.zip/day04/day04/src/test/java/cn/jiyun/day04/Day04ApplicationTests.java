package cn.jiyun.day04;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day04ApplicationTests {

    @Test
    void contextLoads() {
    }

}
