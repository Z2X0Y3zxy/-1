package cn.jiyun.day04.controller;

import cn.jiyun.day04.pojo.Student;
import cn.jiyun.day04.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("student")
@RestController
public class StudentController {

    @Autowired
    private StudentService studentService;

    @CrossOrigin
    @RequestMapping("selectAll")
    public Object selectAll(){
        List<Student> list=studentService.selectAll();
        return list;
    }

    @CrossOrigin
    @RequestMapping("add")
    public Object add(@RequestBody Student student){
        int i=0;
        i=studentService.add(student);
        return i;
    }

    @CrossOrigin
    @RequestMapping("update")
    public Object update(@RequestBody Student student){
        int i=0;
        i=studentService.update(student);
        return i;
    }

    @CrossOrigin
    @RequestMapping("delete/{id}")
    public Object delete(@PathVariable("id") int id){
        int i=0;
        i=studentService.delete(id);
        return i;
    }

}
