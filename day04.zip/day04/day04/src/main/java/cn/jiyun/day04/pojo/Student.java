package cn.jiyun.day04.pojo;

public class Student {
    private int stuId;
    private String stuName;
    private int stuAge;
    private Classes cls;
    private String stuOrigin;
    private String stuAddress;
    private String stuPhone;

    @Override
    public String toString() {
        return "Student{" +
                "stuId=" + stuId +
                ", stuName='" + stuName + '\'' +
                ", stuAge=" + stuAge +
                ", cls=" + cls +
                ", stuOrigin='" + stuOrigin + '\'' +
                ", stuAddress='" + stuAddress + '\'' +
                ", stuPhone='" + stuPhone + '\'' +
                '}';
    }

    public int getStuId() {
        return stuId;
    }

    public void setStuId(int stuId) {
        this.stuId = stuId;
    }

    public String getStuName() {
        return stuName;
    }

    public void setStuName(String stuName) {
        this.stuName = stuName;
    }

    public int getStuAge() {
        return stuAge;
    }

    public void setStuAge(int stuAge) {
        this.stuAge = stuAge;
    }

    public Classes getCls() {
        return cls;
    }

    public void setCls(Classes cls) {
        this.cls = cls;
    }

    public String getStuOrigin() {
        return stuOrigin;
    }

    public void setStuOrigin(String stuOrigin) {
        this.stuOrigin = stuOrigin;
    }

    public String getStuAddress() {
        return stuAddress;
    }

    public void setStuAddress(String stuAddress) {
        this.stuAddress = stuAddress;
    }

    public String getStuPhone() {
        return stuPhone;
    }

    public void setStuPhone(String stuPhone) {
        this.stuPhone = stuPhone;
    }

    public Student() {
    }

    public Student(int stuId, String stuName, int stuAge, Classes cls, String stuOrigin, String stuAddress, String stuPhone) {
        this.stuId = stuId;
        this.stuName = stuName;
        this.stuAge = stuAge;
        this.cls = cls;
        this.stuOrigin = stuOrigin;
        this.stuAddress = stuAddress;
        this.stuPhone = stuPhone;
    }
}
