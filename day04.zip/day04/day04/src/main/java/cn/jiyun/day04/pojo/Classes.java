package cn.jiyun.day04.pojo;

public class Classes {

    private int clsId;
    private String clsName;

    @Override
    public String toString() {
        return "Classes{" +
                "clsId=" + clsId +
                ", clsName='" + clsName + '\'' +
                '}';
    }

    public int getClsId() {
        return clsId;
    }

    public void setClsId(int clsId) {
        this.clsId = clsId;
    }

    public String getClsName() {
        return clsName;
    }

    public void setClsName(String clsName) {
        this.clsName = clsName;
    }

    public Classes() {
    }

    public Classes(int clsId, String clsName) {
        this.clsId = clsId;
        this.clsName = clsName;
    }
}
