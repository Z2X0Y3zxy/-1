package cn.jiyun.day04;


import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(basePackages = "cn.jiyun.day04.dao")
public class Day04Application {

    public static void main(String[] args) {
        SpringApplication.run(Day04Application.class, args);
    }

}
