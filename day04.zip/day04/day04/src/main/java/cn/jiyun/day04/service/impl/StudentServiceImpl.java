package cn.jiyun.day04.service.impl;


import cn.jiyun.day04.dao.StudentDao;
import cn.jiyun.day04.pojo.Student;
import cn.jiyun.day04.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentDao studentDao;


    @Override
    public List<Student> selectAll() {
        return studentDao.selectAll();
    }

    @Override
    public int add(Student student) {
        return studentDao.add(student);
    }

    @Override
    public int update(Student student) {
        return studentDao.update(student);
    }

    @Override
    public int delete(int id) {
        return studentDao.delete(id);
    }
}
