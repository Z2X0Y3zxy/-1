package cn.jiyun.day04.dao;

import cn.jiyun.day04.pojo.Student;

import java.util.List;

public interface StudentDao {
    List<Student> selectAll();

    int delete(int id);

    int update(Student student);

    int add(Student student);
}
