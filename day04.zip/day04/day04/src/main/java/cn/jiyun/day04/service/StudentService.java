package cn.jiyun.day04.service;

import cn.jiyun.day04.pojo.Student;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface StudentService {
    List<Student> selectAll();

    int add(Student student);

    int update(Student student);

    int delete(int id);
}
