package com.example.day01.mapper;

import com.example.day01.controller.SelectController;
import com.example.day01.pojo.Ym;
import org.apache.ibatis.annotations.Select;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public interface YmMapper {


    @Select("select * from ym")
    List<Ym> sekectAll();

}
