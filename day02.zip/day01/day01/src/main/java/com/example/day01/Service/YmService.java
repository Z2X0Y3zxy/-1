package com.example.day01.Service;

import com.example.day01.mapper.YmMapper;
import com.example.day01.pojo.Ym;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class YmService {

    @Autowired
    public YmMapper um;

    public List<Ym> selectAll(){
        return um.sekectAll();
    }

}
