package com.example.day01.controller;

import com.example.day01.mapper.YmMapper;
import com.example.day01.pojo.Ym;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequestMapping("select")
@RestController
@MapperScan("com.example.day01.mapper")
public class SelectController {


    @Autowired
    public YmMapper ymMapper;

    @RequestMapping("selectAll")
    public List<Ym> selectAll(){
        return ymMapper.sekectAll();
    }

}
