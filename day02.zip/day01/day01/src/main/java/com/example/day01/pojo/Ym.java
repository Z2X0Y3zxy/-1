package com.example.day01.pojo;

import java.util.Date;

public class Ym {
    private String id;

    private String name;
    private String pic;
    private String price;
    private String factory;
    private String ytype;
    private String td;
    private Date caretetime;

    @Override
    public String toString() {
        return "Ym{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", pic='" + pic + '\'' +
                ", price='" + price + '\'' +
                ", factory='" + factory + '\'' +
                ", ytype='" + ytype + '\'' +
                ", td='" + td + '\'' +
                ", caretetime=" + caretetime +
                '}';
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getFactory() {
        return factory;
    }

    public void setFactory(String factory) {
        this.factory = factory;
    }

    public String getYtype() {
        return ytype;
    }

    public void setYtype(String ytype) {
        this.ytype = ytype;
    }

    public String getTd() {
        return td;
    }

    public void setTd(String td) {
        this.td = td;
    }

    public Date getCaretetime() {
        return caretetime;
    }

    public void setCaretetime(Date caretetime) {
        this.caretetime = caretetime;
    }

    public Ym() {
    }

    public Ym(String id, String name, String pic, String price, String factory, String ytype, String td, Date caretetime) {
        this.id = id;
        this.name = name;
        this.pic = pic;
        this.price = price;
        this.factory = factory;
        this.ytype = ytype;
        this.td = td;
        this.caretetime = caretetime;
    }
}
